package com.example.test2; // Your package name

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private long lastTimestamp = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Make sure this layout exists

        // Show the feedback form as a dialog
        showFeedbackDialog();
    }

    // Function to show the feedback form dialog
    private void showFeedbackDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View feedbackView = inflater.inflate(R.layout.activity_feedback, null);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(feedbackView).setCancelable(true);

        // Initialize input fields and buttons
        final EditText firstNameEditText = feedbackView.findViewById(R.id.first_name);
        final EditText lastNameEditText = feedbackView.findViewById(R.id.last_name);
        final EditText phoneNumberEditText = feedbackView.findViewById(R.id.phone_number);
        final EditText commentEditText = feedbackView.findViewById(R.id.comment);
        Button sendButton = feedbackView.findViewById(R.id.send_button);
        Button resetButton = feedbackView.findViewById(R.id.reset_button);

        // Send button click listener
        sendButton.setOnClickListener(v -> {
            // Get values from the form fields
            String firstName = firstNameEditText.getText().toString();
            String lastName = lastNameEditText.getText().toString();
            String phoneNumber = phoneNumberEditText.getText().toString();
            String comment = commentEditText.getText().toString();

            // Pass the data to the next activity
            Intent intent = new Intent(MainActivity.this, FeedbackDisplayActivity.class);
            intent.putExtra("FIRST_NAME", firstName);
            intent.putExtra("LAST_NAME", lastName);
            intent.putExtra("PHONE_NUMBER", phoneNumber);
            intent.putExtra("COMMENT", comment);

            startActivity(intent);
        });

        // Reset button click listener
        resetButton.setOnClickListener(v -> {
            firstNameEditText.setText("");
            lastNameEditText.setText("");
            phoneNumberEditText.setText("");
            commentEditText.setText("");
        });

        // Remove title and show the dialog
        AlertDialog dialog = builder.create();
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        dialog.show();
    }

    // Logging elapsed time
    private void logElapsedTime(String event) {
        long currentTimestamp = System.currentTimeMillis();
        if (lastTimestamp != 0) {
            long elapsedTime = currentTimestamp - lastTimestamp;
            android.util.Log.d("EVH_Demo: ", event + " | Elapsed Time: " + elapsedTime + " ms");
        } else {
            android.util.Log.d("EVH_Demo: ", event);
        }
        lastTimestamp = currentTimestamp;
    }

    @Override
    protected void onStart() {
        super.onStart();
        logElapsedTime("onStart()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        logElapsedTime("onRestart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        logElapsedTime("onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        logElapsedTime("onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        logElapsedTime("onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        logElapsedTime("onDestroy()");
    }
}





