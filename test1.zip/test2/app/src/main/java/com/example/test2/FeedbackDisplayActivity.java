package com.example.test2; // Your package name

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class FeedbackDisplayActivity extends AppCompatActivity {
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback_display); // Make sure this layout exists

        // Get data from the Intent
        Intent intent = getIntent();
        String firstName = intent.getStringExtra("FIRST_NAME");
        String lastName = intent.getStringExtra("LAST_NAME");
        String phoneNumber = intent.getStringExtra("PHONE_NUMBER");
        String comment = intent.getStringExtra("COMMENT");

        // Handle null values and display the feedback information
        TextView feedbackTextView = findViewById(R.id.feedbackTextView);
        feedbackTextView.setText("First Name: " + (firstName != null ? firstName : "N/A") + "\n" +
                "Last Name: " + (lastName != null ? lastName : "N/A") + "\n" +
                "Phone Number: " + (phoneNumber != null ? phoneNumber : "N/A") + "\n" +
                "Comment: " + (comment != null ? comment : "N/A"));
    }
}


